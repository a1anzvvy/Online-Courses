# CMU16824hw3
assignment 3 for course 16824
